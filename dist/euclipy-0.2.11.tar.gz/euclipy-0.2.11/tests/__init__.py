'''
Tests for euclipy
'''
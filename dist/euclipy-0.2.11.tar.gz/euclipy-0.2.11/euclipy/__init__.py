'''
Euclipy initialization file
'''